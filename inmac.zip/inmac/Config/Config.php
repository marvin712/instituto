<?php
    const BASE_URL = "http://localhost/inmac";

    //Zona horaria
    date_default_timezone_set('America/Guatemala');

    //Datos de conexión a Base de Datos
    const DB_HOST = "localhost";
    const DB_NAME = "instituto";
    const DB_USER = "root";
    const DB_PASSWORD = "root";
    const DB_CHARSET = "charset=utf-8";

    //Delimitadores decimal y millar Ej. 24,1989.00
    const SPD =".";
    const SPM =",";

    //Simbolo de moneda
    const SMONEY = "Q";
?>