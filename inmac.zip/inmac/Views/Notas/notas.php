<?php headerProfesor($data); ?>
<?php require_once('./Views/Profesores/nav_profesores.php'); ?>
<?php require_once('./Views/Profesores/profesores_header.php'); ?>
<?php require_once('./Controllers/CursosProfesor.php'); ?>
<!--  -->
<div class="container-fluid container-cards">
    <!-- Tittle -->
    <h1 class="h2 pb-4">Notas | Instituto Alejandro Córdova</h1>
    <!-- Button trigger modal -->


<?php footerProfesor($data); ?>