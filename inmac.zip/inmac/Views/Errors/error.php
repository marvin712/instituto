<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instituto Inmac</title>
    <link rel="stylesheet" href="<?= media(); ?>/css/style.css">
  <link rel="shortcut icon" href="<?= media(); ?>/images/logo.ico.png" type="image/x-icon">
</head>
<body class="body-error">
    <h2>Pagina no encontrada</h2>
    <a href="<?php base_url();?>/inmac" class="btn-error btn btn-outline-secondary">Ir a inicio</a>
</body>
</html>