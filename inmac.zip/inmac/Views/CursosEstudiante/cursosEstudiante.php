<?php headerEstudiante($data);?>
<?php require_once('./Views/Estudiantes/nav_estudiantes.php');?>
<?php require_once('./Views/Estudiantes/estudiantes_header.php');?>
    
<?php footerEstudiante($data);?>